from django.apps import AppConfig


class NewlouslistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'NewLousList'
